The following files were generated for 'sign32div16' in directory 
V:\CD\EIE\projects\LINAC_UPGRADE\MKSU\MKSUII\chassis\xilinx\mksuii_x\ipcore_dir\

sign32div16.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

sign32div16.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

sign32div16.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

sign32div16.sym:
   Please see the core data sheet.

sign32div16.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

sign32div16.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

sign32div16.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

sign32div16.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

sign32div16.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

sign32div16.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

sign32div16_readme.txt:
   Text file indicating the files generated and how they are used.

sign32div16_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

sign32div16_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

