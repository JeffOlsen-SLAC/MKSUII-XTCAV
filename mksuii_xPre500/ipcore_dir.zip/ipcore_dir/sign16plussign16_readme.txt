The following files were generated for 'sign16plussign16' in directory 
V:\CD\EIE\projects\LINAC_UPGRADE\MKSU\MKSUII\chassis\xilinx\mksuii_x\ipcore_dir\

sign16plussign16.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

sign16plussign16.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

sign16plussign16.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

sign16plussign16.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

sign16plussign16.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

sign16plussign16.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

sign16plussign16.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

sign16plussign16.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

sign16plussign16.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

sign16plussign16_readme.txt:
   Text file indicating the files generated and how they are used.

sign16plussign16_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

sign16plussign16_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

