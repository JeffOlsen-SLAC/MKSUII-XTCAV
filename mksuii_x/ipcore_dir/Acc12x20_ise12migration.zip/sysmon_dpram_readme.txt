The following files were generated for 'sysmon_dpram' in directory 
V:\CD\ILC\hardware\Chassis\P2_Marx\HardwareManager\xilinx\HardwareManager_x\ipcore_dir\

dist_mem_gen_ds322.pdf:
   Please see the core data sheet.

dist_mem_gen_readme.txt:
   Text file indicating the files generated and how they are used.

sysmon_dpram.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

sysmon_dpram.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

sysmon_dpram.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

sysmon_dpram.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

sysmon_dpram.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

sysmon_dpram.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

sysmon_dpram.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

sysmon_dpram.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

sysmon_dpram.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

sysmon_dpram_readme.txt:
   Text file indicating the files generated and how they are used.

sysmon_dpram_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

sysmon_dpram_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

