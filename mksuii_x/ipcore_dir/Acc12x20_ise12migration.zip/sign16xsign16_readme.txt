The following files were generated for 'sign16xsign16' in directory 
X:\xilinx\mksuii_x\ipcore_dir\

sign16xsign16.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

sign16xsign16.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

sign16xsign16.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

sign16xsign16.sym:
   Please see the core data sheet.

sign16xsign16.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

sign16xsign16.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

sign16xsign16.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

sign16xsign16.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

sign16xsign16.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

sign16xsign16.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

sign16xsign16_readme.txt:
   Text file indicating the files generated and how they are used.

sign16xsign16_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

sign16xsign16_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

