The following files were generated for 'subu16u16' in directory 
V:\groups\cd\eie\projects\linac_upgrade\mksu\mksuii\chassis\xilinx\mksuii_x\ipcore_dir\

subu16u16.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

subu16u16.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

subu16u16.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

subu16u16.sym:
   Please see the core data sheet.

subu16u16.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

subu16u16.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

subu16u16.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

subu16u16.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

subu16u16.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

subu16u16.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

subu16u16_readme.txt:
   Text file indicating the files generated and how they are used.

subu16u16_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

subu16u16_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

