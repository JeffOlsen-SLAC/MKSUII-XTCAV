The following files were generated for 'sign63div16' in directory
S:\cd\eie\projects\linac_upgrade\mksu\mksuii\chassis\xilinx\mksuii_x\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * sign63div16.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * sign63div16.ngc
   * sign63div16.vhd
   * sign63div16.vho

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * sign63div16.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * sign63div16.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * sign63div16.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * sign63div16_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * sign63div16.gise
   * sign63div16.xise

Deliver Readme:
   Text file indicating the files generated and how they are used.

   * sign63div16_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * sign63div16_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

